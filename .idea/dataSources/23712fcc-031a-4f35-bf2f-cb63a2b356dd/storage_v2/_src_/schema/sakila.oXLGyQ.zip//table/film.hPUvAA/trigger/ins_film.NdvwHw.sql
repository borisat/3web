create definer = root@localhost trigger ins_film
    after insert
    on film
    for each row
BEGIN
    INSERT INTO film_text (film_id, title, description)
        VALUES (new.film_id, new.title, new.description);
  END;

